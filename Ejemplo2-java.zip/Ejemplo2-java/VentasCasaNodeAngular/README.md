# VentasCasaNodeAngular

Esta plantilla reproduce la estructura de un entorno Node.js portable y dos proyectos (backend y frontend) adaptada a un caso de uso de "ventas de casas".

Contenido principal:
- `iniciar-entorno.bat` - script para preparar un entorno Node.js portable (usa `nodejs/` y `npm-cache/`).
- `nodejs/` - lugar para colocar una distribución portable de Node.js (no incluye binarios en esta plantilla).
- `npm-cache/` - caché local de npm.
- `proyectos/ventas-backend/` - backend Express para gestionar ventas de casas.
- `proyectos/ventas-front/` - esqueleto del frontend (Angular) con scripts mínimos.

Uso rápido:
1. Copia una distribución portable de Node en `nodejs/` (ej. `node.exe` y herramientas npm), o usa Node instalado globalmente.
2. Desde la raíz de esta carpeta, ejecuta `iniciar-entorno.bat`.
3. En la consola que se abre en `proyectos/`, entra en `ventas-backend` y ejecuta `npm install` y luego `npm run dev`.
4. En `ventas-front` ejecuta `npm install` y `npm start` (o `ng serve` si tienes Angular CLI en local).

Notas:
- El backend por defecto sirve en el puerto `3500` y permite CORS desde `http://localhost:4300`.
- El frontend está configurado para servir en `4300` (puedes cambiar puertos según necesites).
