@echo off
TITLE Entorno Ventas Casa - Node.js Portable

REM Definir rutas absolutas
SET BASE_DIR=%~dp0
SET NODE_PATH=%BASE_DIR%nodejs
SET NPM_CONFIG_PREFIX=%BASE_DIR%npm-global-ventas
SET NPM_CONFIG_CACHE=%BASE_DIR%npm-cache

REM Crear carpetas necesarias si no existen
if not exist "%NPM_CONFIG_PREFIX%" mkdir "%NPM_CONFIG_PREFIX%"
if not exist "%NPM_CONFIG_CACHE%" mkdir "%NPM_CONFIG_CACHE%"

REM Verificar existencia del ejecutable de Node
if exist "%NODE_PATH%\node.exe" (
  set USE_NODE_PATH=1
) else (
  set USE_NODE_PATH=0
)

if "%USE_NODE_PATH%"=="0" (
  where node >nul 2>&1
  if errorlevel 1 (
    echo ERROR: Node no encontrado en %NODE_PATH% ni en PATH.
    echo Copia una distribución portable de Node (node.exe) dentro de "%NODE_PATH%" o instala Node globalmente.
    pause
    exit /b 1
  )
)

REM Construir comando para ejecutar en nueva ventana CMD
set "CMD_LINE="
if "%USE_NODE_PATH%"=="1" (
  set "CMD_LINE=call ^"%NODE_PATH%\npm^" config set prefix ^"%NPM_CONFIG_PREFIX%^" ^&^& call ^"%NODE_PATH%\npm^" config set cache ^"%NPM_CONFIG_CACHE%^" ^&^& echo ========================== ^& echo Entorno Ventas Casa (Node.js Portable) ^& echo ========================== ^& echo. ^& echo Node version: ^& call node --version ^& echo NPM version: ^& call ^"%NODE_PATH%\npm^" --version ^& echo. ^& echo Directorio actual: %CD% ^& echo ========================== ^& cd /d ^"%BASE_DIR%proyectos^""
) else (
  set "CMD_LINE=call npm config set prefix ^"%NPM_CONFIG_PREFIX%^" ^&^& call npm config set cache ^"%NPM_CONFIG_CACHE%^" ^&^& echo ========================== ^& echo Entorno Ventas Casa (Node.js Portable) ^& echo ========================== ^& echo. ^& echo Node version: ^& call node --version ^& echo NPM version: ^& call npm --version ^& echo. ^& echo Directorio actual: %CD% ^& echo ========================== ^& cd /d ^"%BASE_DIR%proyectos^""
)

REM Abrir nueva ventana CMD para el entorno
start "Entorno Ventas Casa" cmd /k %CMD_LINE%
exit /b 0
